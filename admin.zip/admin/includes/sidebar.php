


<div class="left-sidebar-pro">
        <nav id="sidebar" class="">
            <div class="sidebar-header">
                <a href="index"><img class="main-logo" src="../images/general-elements/logo/logo1.png" width="205px" height="80px" alt="" /></a>
                <strong><img src="../images/general-elements/logo/logo1.png" alt="" width="205px" height="80px"/></strong>
            </div>
            <div class="left-custom-menu-adp-wrap comment-scrollbar">
                <nav class="sidebar-nav left-sidebar-menu-pro">
                    <ul class="metismenu" id="menu1">
                        <li><a title="Dashboard" href="index" aria-expanded="false"><i class="fa fa-home icon-wrap sub-icon-mg" aria-hidden="true"></i> <span class="mini-click-non">Dashboard</span></a></li>
                        <li>
                            <a class="has-arrow" href="" aria-expanded="false"><i class="fa fa-newspaper-o"></i> <span class="mini-click-non">Blog/News</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                            <li><a title="Create New Post" href="writenew.php"><i class="fa fa-align-justify sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Create New</span></a></li>
                                <li><a title="Blog History" href="blog-history.php"><i class="fa fa-level-down sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Blog History</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="" aria-expanded="false"><i class="fa fa-calendar"></i> <span class="mini-click-non">Event</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                            <li><a title="Create New Event" href="writenewevent.php"><i class="fa fa-align-justify sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Create New</span></a></li>
                                <li><a title="Event History" href="event-history.php"><i class="fa fa-level-down sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Event History</span></a></li>
                            </ul>
                        </li>
                        <li>
                            <a class="has-arrow" href="" aria-expanded="false"><i class="fa fa-newspaper-o"></i> <span class="mini-click-non">Media Mention</span></a>
                            <ul class="submenu-angle" aria-expanded="false">
                            <li><a title="Create New Event" href="writenew-in-media.php"><i class="fa fa-align-justify sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Create New</span></a></li>
                                <li><a title="Event History" href="media-mention-history.php"><i class="fa fa-level-down sub-icon-mg" aria-hidden="true"></i> <span class="mini-sub-pro">Media Mention History</span></a></li>
                            </ul>
                        </li>
                       
                        <li><a title="Landing Page" href="#" aria-expanded="false"><i class="fa fa-bookmark icon-wrap sub-icon-mg" aria-hidden="true"></i> <span class="mini-click-non">Landing Page</span></a></li>
                    </ul>
                </nav>
            </div>
        </nav>
    </div>