

<div class="footer-copyright-area" style="background: #192958;">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-copy-right">
                            <p>Copyright &copy; 2021 <a href="../">Casafrique 2021</a> All rights reserved.<br>Designed by <a href="https://www.linkedin.com/in/ayorinde-g-smart-bba36169/" target="_blank" >SAG Enconders </a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>