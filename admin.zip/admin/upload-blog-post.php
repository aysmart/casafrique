<?php
include('includes/config.php');
$ptitle = $_POST["ptitle"];
$pcateg = $_POST["pcateg"];
$ptags = $_POST["ptags"];
$pcontent = $_POST["pcontent"];
$bannerImage = $_POST["bannerImage"];


mysqli_query($con,"INSERT INTO blogpost(Category, BlogTittle, PostedBy, ContentText, PostBanner, PostTags) values('$pcateg','$ptitle','Marketing Admin', '$pcontent','$bannerImage','$ptags')");    

$last_id = mysqli_insert_id($con);

if($last_id>0){
    echo 'Upload was successful.';
  }
  else{
    echo 'Upload was not successful, check and try again!';
  }
?>
